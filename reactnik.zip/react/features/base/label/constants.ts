export const COLORS = {
    white: 'white',
    green: 'green',
    red: 'red'
};
