import { getLogger } from '../logging/functions';

export default getLogger('app:net-info');
