export const SECURITY_URL = 'https://jitsi.org/security/';
