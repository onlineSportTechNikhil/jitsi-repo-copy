/**
 * Custom theme for setting client branding.
 *
 * @param {Object} theme - The ui tokens theme object.
 * @returns {Object}
 */
export default function updateTheme(theme: Object) {
    return theme;
}
