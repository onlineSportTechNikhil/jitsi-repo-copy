export { default } from '../../../ui/components/web/Spinner';
