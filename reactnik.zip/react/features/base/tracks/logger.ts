import { getLogger } from '../logging/functions';

export default getLogger('app:tracks');
