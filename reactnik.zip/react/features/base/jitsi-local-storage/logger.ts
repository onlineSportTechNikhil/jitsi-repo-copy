import { getLogger } from '../logging/functions';

export default getLogger('app:jitsi-local-storage');
