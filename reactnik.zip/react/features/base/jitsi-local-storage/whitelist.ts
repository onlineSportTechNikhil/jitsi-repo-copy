/**
 * Keys of localStorage that are used by jibri.
 */
export default [
    'callStatsUserName',
    'displayname',
    'email',
    'xmpp_username_override',
    'xmpp_password_override',
    'xmpp_conference_password_override'
];
