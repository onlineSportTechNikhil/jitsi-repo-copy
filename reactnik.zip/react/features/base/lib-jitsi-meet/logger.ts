import { getLogger } from '../logging/functions';

export default getLogger('app:lib-jitsi-meet');
