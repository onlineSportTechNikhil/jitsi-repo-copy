declare let JitsiMeetJS: any;

export default JitsiMeetJS;
