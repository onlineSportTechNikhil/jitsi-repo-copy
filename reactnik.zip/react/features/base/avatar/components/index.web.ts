export { default as StatelessAvatar } from './web/StatelessAvatar';
