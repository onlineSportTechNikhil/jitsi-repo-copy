export { default as StatelessAvatar } from './native/StatelessAvatar';
