import { getLogger } from '../base/logging/functions';

export default getLogger('app:authentication');
