/**
 * The name of the bundled audio file which will be played for the raise hand sound.
 *
 * @type {string}
 */
export const ASKED_TO_UNMUTE_FILE = 'asked-unmute.mp3';
