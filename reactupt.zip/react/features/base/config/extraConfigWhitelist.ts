/**
 * Deploy-specific configuration whitelists.
 */
export default [];
