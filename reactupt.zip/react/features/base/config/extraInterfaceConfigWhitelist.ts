/**
 * Deploy-specific interface_config whitelists.
 */
export default [];
