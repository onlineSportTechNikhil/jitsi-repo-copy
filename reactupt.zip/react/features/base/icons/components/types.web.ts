import React from 'react';

export interface IIconProps {
    onClick?: (e?: React.MouseEvent) => void;
}
