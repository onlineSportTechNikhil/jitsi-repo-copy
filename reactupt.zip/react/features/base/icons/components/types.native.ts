import { GestureResponderEvent } from 'react-native';

export interface IIconProps {
    onClick?: (e?: GestureResponderEvent) => void;
}
