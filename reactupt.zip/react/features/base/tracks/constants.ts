/**
 * The payload name for remotely setting the camera facing mode message.
 */
export const CAMERA_FACING_MODE_MESSAGE = 'camera-facing-mode-message';
export const LOWER_HAND_MESSAGE = 'lower-hand-message';
