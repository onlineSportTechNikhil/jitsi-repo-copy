import BaseTheme from '../BaseTheme.native';

export const ENABLED_TRACK_COLOR = BaseTheme.palette.action01;
export const DISABLED_TRACK_COLOR = BaseTheme.palette.ui05;
export const THUMB_COLOR = BaseTheme.palette.icon01;
