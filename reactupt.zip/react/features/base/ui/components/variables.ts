/**
 * Prejoin / premeeting screen.
 */

// Maps SCSS variable $prejoinDefaultContentWidth
export const PREJOIN_DEFAULT_CONTENT_WIDTH = '336px';
