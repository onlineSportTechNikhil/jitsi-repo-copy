/**
 * The base URL for gravatar images.
 */
export const GRAVATAR_BASE_URL = 'https://www.gravatar.com/avatar/';
