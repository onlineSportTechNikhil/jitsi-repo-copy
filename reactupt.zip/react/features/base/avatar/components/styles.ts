// Colors for avatar status badge
export const PRESENCE_AVAILABLE_COLOR = 'rgb(110, 176, 5)';
export const PRESENCE_AWAY_COLOR = 'rgb(250, 201, 20)';
export const PRESENCE_BUSY_COLOR = 'rgb(233, 0, 27)';
export const PRESENCE_IDLE_COLOR = 'rgb(172, 172, 172)';
