export const CONNECTION_TYPE = {
    FAILED: 'failed',
    GOOD: 'good',
    NON_OPTIMAL: 'nonOptimal',
    NONE: 'none',
    POOR: 'poor',
    RUNNING: 'running'
};
