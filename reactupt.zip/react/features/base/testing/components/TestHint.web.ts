import { Component } from 'react';

export default Component;
