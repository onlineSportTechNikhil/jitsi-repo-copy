export enum IGUMPendingState {
    PENDING_UNMUTE = 1,
    NONE = 2
}
