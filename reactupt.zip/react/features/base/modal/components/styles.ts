
export default {

    jitsiScreenContainer: {
        flex: 1
    },

    safeArea: {
        flex: 1
    }
};
