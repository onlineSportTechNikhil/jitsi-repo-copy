module.exports = {
    plugins: [
        'react-native'
    ],
    rules: {
        'react-native/no-color-literals': 2,
        'react-native/no-inline-styles': 2,
        'react-native/no-unused-styles': 2,
        'react-native/split-platform-components': 2
    }
};
